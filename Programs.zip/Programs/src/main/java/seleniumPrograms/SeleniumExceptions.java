package seleniumPrograms;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SeleniumExceptions {
	
	public static WebDriver driver;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 System.setProperty("webdriver.chrome.driver", "D:\\Selenium Testing\\Programs\\src\\main\\java\\driver\\chromedriver.exe");
			
			driver = new ChromeDriver();
			
			driver.get("https://www.w3schools.com/sql/sql_syntax.asp");
			
		try {
			BufferedReader br = new BufferedReader(new FileReader("Data"));
		    }
		   catch(FileNotFoundException file){
		      file.printStackTrace();
		    }
		   catch(IOException ie)
		    {
		      ie.printStackTrace();
		    } 
		
		   try {
			driver.findElement(By.id("submit")).click();
			} catch (WebDriverException e) {
			e.printStackTrace();
			}
		   
		   try {
			   driver.switchTo().alert().accept();
			   } catch (NoAlertPresentException e) {
			   e.printStackTrace();
			   }
		   
		   try {
			   driver.findElement(By.id("submit")).click();
			   } catch (ElementNotVisibleException e) {
				   e.printStackTrace();
			   }
		   
		     try {
			   Select dropdown = new Select(driver.findElement(By.id("swift")));
			   } catch (WebDriverException e) {
			   System.out.println("Exceptional case");
			   }
	}

}
