package seleniumPrograms;
import java.time.Duration;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class WaitExamp {
	
	protected static WebDriver driver;
	
	public static void main(String args[]) throws InterruptedException 
	{
		 System.setProperty("webdriver.chrome.driver", "D:\\Selenium Testing\\Programs\\src\\main\\java\\driver\\chromedriver.exe");
			
		driver = new ChromeDriver();
		
		//implicit wait
		
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;
			
		driver.get("https://www.w3schools.com/sql/sql_syntax.asp");
			
		  driver.manage().window().maximize() ;
	
	    String eTitle = "SQL Syntax";
	
	    String aTitle = "" ;


  
        aTitle = driver.getTitle();
        
        System.out.print(aTitle);

        if (aTitle.equals(eTitle))
        {
           System.out.println( "Test Passed") ;
        }
       else {
           System.out.println( "Test Failed" );
           }
        
        //Explicit Wait
        
      WebDriverWait wait=new WebDriverWait(driver, 20);
      
      WebElement ele= wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(" Try it Yourself »")));
      ele.click();
  	  
  	   //fluent Wait
  	   

      Wait<WebDriver> wait1 = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(10))
                   .pollingEvery(Duration.ofSeconds(5)).ignoring(NoSuchElementException.class);

    wait.until(new Function<WebDriver, Boolean>() {
            public Boolean apply(WebDriver driver) {
              return driver.findElement(By.xpath("/html/body/div[6]/div[1]/div[1]/h2[1]")).getText().contains("Database Tables");
         }
      });
  		


    
      driver.close();
      
}
}
