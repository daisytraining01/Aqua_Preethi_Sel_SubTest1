package seleniumPrograms;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.mongodb.assertions.Assertions;

import junit.framework.Assert;

public class Registration {
	
	static String path = System.getProperty("user.dir");
	
	public static WebDriver driver;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "D:\\Selenium Testing\\Programs\\src\\main\\java\\driver\\chromedriver.exe");
		
		driver = new ChromeDriver();
		
		driver.get("http://demo.guru99.com/test/newtours/register.php");
		
		driver.manage().window().maximize();
		
		//Multiple Records
		
		Object[][] list= { {"preethi","Shivegowda","8970528995","preethi@gmail.com","1st main","Bangalore","Karnataka","573225","preethi@gmail.com","12345","12345"},
				           {"uma","gowda","1234567890","uma@gmail.com","2nd main","Hassan","Karnataka","573225","uma@gamil.com","12345","12345"},
				           {"usha","gowda","1234567890","usha@gmail.com","3rd main","Hassan","Karnataka","573225","usha@gmail.com","12345","1234"}};
		
		for(int i=0;i<list.length;i++) {
			
			List<Object> ar= Arrays.asList(list[i]);
			
			Object[] ar1= list[i];
			
			//System.out.print(ar);
			
		//driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);	
			
		
		driver.findElement(By.name("firstName")).sendKeys(""+ar1[0]);
		
		driver.findElement(By.name("lastName")).sendKeys(""+ar1[1]);
		
		driver.findElement(By.name("phone")).sendKeys(""+ar1[2]);
		
		driver.findElement(By.name("userName")).sendKeys(""+ar1[3]);
		
		driver.findElement(By.name("address1")).sendKeys(""+ar1[4]);
		
		driver.findElement(By.name("city")).sendKeys(""+ar1[5]);
		
		driver.findElement(By.name("state")).sendKeys(""+ar1[6]);
		
		driver.findElement(By.name("postalCode")).sendKeys(""+ar1[7]);
		
		Select value=new Select(driver.findElement(By.name("country")));
		
		value.selectByVisibleText("AUSTRALIA");
		
		driver.findElement(By.name("email")).sendKeys(""+ar1[8]);
		
		driver.findElement(By.name("password")).sendKeys(""+ar1[9]);
		
		driver.findElement(By.name("confirmPassword")).sendKeys(""+ar1[10]);	
      
        
        String s1=driver.findElement(By.name("firstName")).getAttribute("value");
        
        String s2= driver.findElement(By.name("lastName")).getAttribute("value");
     
		//printing al the inputs in commandline
        
        System.out.println(driver.findElement(By.name("phone")).getAttribute("value"));
		
        System.out.println(driver.findElement(By.name("userName")).getAttribute("value"));
		
        System.out.println(driver.findElement(By.name("address1")).getAttribute("value"));
		
        System.out.println(driver.findElement(By.name("city")).getAttribute("value"));
        
        System.out.println(driver.findElement(By.name("postalCode")).getAttribute("value"));
		
        System.out.println(driver.findElement(By.name("country")).getText());
		
		//value.selectByVisibleText("AUSTRALIA");
		
        System.out.println(driver.findElement(By.name("email")).getAttribute("value"));
		
        System.out.println(driver.findElement(By.name("password")).getAttribute("value"));
		
        System.out.println(driver.findElement(By.name("confirmPassword")).getAttribute("value"));
        
        driver.findElement(By.name("submit")).click();
        
        WebElement web=driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[3]/td/p[1]"));
        
        //printing confirmation message
        System.out.print(""+web.getText());
        
        
        WebElement text=driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[3]/td/p[1]/font"));
        
        //System.out.print(""+numOfCol);
        
        String str1=text.getText().replace("Dear", "").trim().replace(",", "");
        
        String str2=s1+" "+s2;
        
        if(!s1.equals("usha")) {
        	
        Assert.assertEquals(str1,str2);
        
        System.out.println("Registration Done Successfully");
        
        driver.findElement(By.xpath("//a[@href ='register.php']")).click(); 
       
        // Taking ScreenShoot
        
        screenshot(str2);
		}else {
        try {
        	
        	//negitive scenario
        	
        	 driver.findElement(By.xpath("//a[@href ='register.php']")).click(); 
        	 
        String passwd = driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[15]/td[2]/span")).getText();
        
        if(passwd.contains("PAssword and con.password does not match"))
        	System.out.println("Password Mismatch");
        else 
        	System.out.println("Registration Unsuccessful");
        
        screenshot(str2);
        }
        catch(Exception e) {
        	
        }
        
		}
       
        
        
		}
	
		driver.close();
	}

	public static void screenshot(String s)
	{
		try {
		String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
		TakesScreenshot screen =((TakesScreenshot)driver);
		File SrcFile=screen.getScreenshotAs(OutputType.FILE);
		File despath = new File(path+"/Screenshots/"+s+timestamp+".jpg");
		FileUtils.copyFile(SrcFile, despath);
		} catch (IOException e) 
		{
			e.printStackTrace();
		}	
	}

}
