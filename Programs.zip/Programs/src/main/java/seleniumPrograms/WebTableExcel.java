package seleniumPrograms;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class WebTableExcel {

	public static WebDriver driver;
	
	 static FileOutputStream fis;
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
       System.setProperty("webdriver.chrome.driver", "D:\\Selenium Testing\\Programs\\src\\main\\java\\driver\\chromedriver.exe");
		
		driver = new ChromeDriver();
		
		driver.get("https://www.w3schools.com/sql/sql_syntax.asp");
		
		driver.manage().window().maximize();

		WebElement table = driver.findElement(By.xpath("/html/body/div[6]/div[1]/div[1]/div[3]/table/tbody"));
		
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        
        int rowcount = rows.size();
        
       
		try {
			fis = new FileOutputStream(new File("D:\\Selenium Testing\\Programs\\excel\\excel.xlsx"));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        
        @SuppressWarnings("resource")
		XSSFWorkbook wb = new XSSFWorkbook();
        
        XSSFSheet sh = wb.createSheet("FirstSheet");
        
        for (int row = 0; row < rowcount; row++) {
        	
        
            List<WebElement> columns_inrow = rows.get(row).findElements(By.tagName("td"));
            
            int columns_count = columns_inrow.size();
            
            System.out.println("Number of cells in Row " + row + " are " + columns_count);
            
            Row ro = sh.createRow(row);
            
            for (int column = 0; column < columns_count; column++) {

                String celltext = columns_inrow.get(column).getText();
                System.out.println(
                        "Cell Value of row number " + row + " and column number " + column + " Is " + celltext);
                ro.createCell(column).setCellValue(celltext);
            }
            System.out.println("===========================");

          
				
			
        }
        
        wb.write(fis);
        WebTableExcel excel=new WebTableExcel();
        
        excel.ReadExcel();
       
        driver.close();
	    
		}
	public void ReadExcel() throws IOException {
		


		FileInputStream inputStream = new FileInputStream("D:\\Selenium Testing\\Programs\\excel\\excel.xlsx");

		Workbook workbook = null;

		String fileName="excel.xlsx";
		
		String fileExtensionName = fileName.substring(fileName.indexOf("."));

		workbook = new XSSFWorkbook(inputStream);

		Sheet sheet = workbook.getSheet("FirstSheet");

		// Find number of rows in excel file

		int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();

		for (int i = 0; i < rowCount + 1; i++) {

			Row row = sheet.getRow(i);

			for (int j = 0; j < row.getLastCellNum(); j++) {

				System.out.print(row.getCell(j).getStringCellValue() + "|| ");

			}

			System.out.println();
		}

	
	}
}
