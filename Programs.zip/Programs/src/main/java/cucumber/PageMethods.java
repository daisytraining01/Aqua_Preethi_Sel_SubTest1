package cucumber;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class PageMethods {
	
	public static WebDriver driver;
	
	public void url() {
		
       System.setProperty("webdriver.chrome.driver", "D:\\Selenium Testing\\Programs\\src\\main\\java\\driver\\chromedriver.exe");
		
		driver = new ChromeDriver();
		
		driver.get("http://demo.guru99.com/test/newtours/register.php");
		
		driver.manage().window().maximize();
	}
	public void RegistrationPageLoad() {
		
		String s1=driver.findElement(By.linkText("Demo Site")).getText();
		
		String s2="Demo Site";
		
		if(s1.equals(s1))
			System.out.println("Page Loaded Successfully");
		else
			System.out.println("Page not Loaded Successfully");	
		
	}
	public void FillInformation() {
		
        driver.findElement(By.name("firstName")).sendKeys("Preethi");
		
		driver.findElement(By.name("lastName")).sendKeys("Shivegowda");
		
		driver.findElement(By.name("phone")).sendKeys("7785678265");
		
		driver.findElement(By.name("userName")).sendKeys("preethi@gmail.com");
		
		driver.findElement(By.name("address1")).sendKeys("1st Main");
		
		driver.findElement(By.name("city")).sendKeys("Bangalore");
		
		driver.findElement(By.name("state")).sendKeys("Karnataka");
		
		driver.findElement(By.name("postalCode")).sendKeys("573228");
		
		Select value=new Select(driver.findElement(By.name("country")));
		
		value.selectByVisibleText("INDIA");
		
		driver.findElement(By.name("email")).sendKeys("Preethi@gmail.com");
		
		driver.findElement(By.name("password")).sendKeys("12345");
		
		driver.findElement(By.name("confirmPassword")).sendKeys("12345");
		
		
	}
	public void submit() {
		
		 driver.findElement(By.name("submit")).click();
	}
	public void getConfirmationMessage() {
		
		String web=driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[3]/td/p[1]/font")).getText();
		
		if(web.contains("Preethi Shivegowda")) {
        	
        	System.out.println("Registration Done SuccessFully");
        	
        }
        else
        	System.out.println("failed Registration ");
	}
	public void Registration() {
		
		driver.findElement(By.xpath("//a[@href ='register.php']")).click(); 
	}
	public void fillUserDetails() {
		
       driver.findElement(By.name("email")).sendKeys("Preethi@gmail.com");
		
		driver.findElement(By.name("password")).sendKeys("12345");
		
		driver.findElement(By.name("confirmPassword")).sendKeys("1234");
	}
	public void RegistrationFailed() {
		
        String passwd = driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[15]/td[2]/span")).getText();
        
        if(passwd.contains("PAssword and con.password does not match"))
        	  System.out.println("Registration Failed");
	}

}
