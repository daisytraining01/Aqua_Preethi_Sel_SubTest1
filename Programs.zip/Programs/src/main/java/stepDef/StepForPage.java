package stepDef;

import cucumber.PageMethods;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepForPage {
	
	PageMethods code =new PageMethods();
	
	@Given("^I have url$")
	public void i_have_url()  
	{
		code.url();
	}
	
	@When("^Registration Page is Loaded$")
	public void Registration_Page_is_Loaded() {
		code.RegistrationPageLoad();
	}
	
	@When("^Fill the Information$")
	public void Fill_Information() {
		code.FillInformation();
	}
	@And("^Sumbit the Page$")
	public void Sumbit_the_Page() {
		code.submit();
	}
	@Then("^able to see Registered Successfull$")
	public void able_to_see_Registered_Successfull() {
		
		System.out.println("Done");
		
	}
	@When("^Registration successfully completed$")
	public void Registration_successfully_completed() {
		
		System.out.println("Done");
	}
	@And("^verify the registration$")
	public void verify_the_registration() {
		code.getConfirmationMessage();
	}
	@Then("^click on registration$")
	public void click_on_registration() {
		
		code.Registration();
	}
	@And("^Fill User Details$")
	public void Fill_User_Details() {
		
		code.fillUserDetails();
		
	}
	@Then("^able to see incomplete registration$")
	public void able_to_see_incomplete_registration() {
		code.RegistrationFailed();
	}

	@Then("^able to see Registered page$")
	public void able_to_see_Registered_page() throws Throwable {
	 
	    
	}
}
